CREATE TABLE [dbo].[Calisanlar] (

	[CalisanID] int NULL, 
	[Ad] varchar(50) NULL, 
	[Departman] varchar(50) NULL, 
	[Maas] int NULL
);