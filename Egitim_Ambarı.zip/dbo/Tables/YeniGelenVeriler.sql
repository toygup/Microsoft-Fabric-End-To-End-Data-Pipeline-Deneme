CREATE TABLE [dbo].[YeniGelenVeriler] (

	[CalisanID] int NULL, 
	[Ad] varchar(50) NULL, 
	[Departman] varchar(50) NULL, 
	[Maas] int NULL
);