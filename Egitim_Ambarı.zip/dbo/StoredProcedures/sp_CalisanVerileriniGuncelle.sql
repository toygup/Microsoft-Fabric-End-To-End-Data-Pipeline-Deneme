CREATE PROCEDURE sp_CalisanVerileriniGuncelle
AS
BEGIN
    BEGIN TRANSACTION;

    BEGIN TRY
        MERGE INTO Calisanlar AS target
        USING YeniGelenVeriler AS source
        ON (target.CalisanID = source.CalisanID)

        WHEN MATCHED THEN
            UPDATE SET 
                target.Departman = source.Departman,
                target.Maas = source.Maas

        WHEN NOT MATCHED THEN
            INSERT (CalisanID, Ad, Departman, Maas)
            VALUES (source.CalisanID, source.Ad, source.Departman, source.Maas);

        COMMIT TRANSACTION;
        PRINT 'Veriler başarıyla güncellendi ve yeni kayıtlar eklendi!';
    END TRY
    
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        PRINT 'Bir hata oluştu! İşlemler geri alındı.';
    END CATCH
END;