WITH TekillestirilmisCalisanlar AS (
SELECT
CalisanID,
Ad,
Departman,
Maas,
ROW_NUMBER() OVER(PARTITION BY CalisanID ORDER BY Maas DESC) AS SiraNo
FROM Calisanlar
)
SELECT CalisanID, Ad, Departman, Maas
FROM TekillestirilmisCalisanlar
WHERE SiraNo=1;
