WITH SiraıMaaslar AS (
SELECT
CalisanID,
Ad,
Departman,
Maas,
DENSE_RANK() OVER(PARTITION BY Departman ORDER  BY Maas DESC) AS Sira
FROM Calisanlar
)
SELECT*FROM SiraliMaaslar
WHERE Sira <=2;

