CREATE TABLE Calisanlar (
    CalisanID INT,
    Ad VARCHAR(50),
    Departman VARCHAR(50),
    Maas INT
);

INSERT INTO Calisanlar (CalisanID, Ad, Departman, Maas) VALUES
(1, 'Ahmet', 'Yazılım', 85000),
(2, 'Ayşe', 'Yazılım', 95000),
(3, 'Mehmet', 'Yazılım', 75000),
(4, 'Fatma', 'Pazarlama', 60000),
(5, 'Ali', 'Pazarlama', 65000),
(6, 'Zeynep', 'Pazarlama', 65000),
(7, 'Can', 'İK', 50000),
(8, 'Ece', 'İK', 55000);
