CREATE TABLE DimDepartman (
    DepartmanID INT PRIMARY KEY,
    DepartmanAdi VARCHAR(50),
    Lokasyon VARCHAR(50)
);

CREATE TABLE DimCalisan (
    CalisanID INT PRIMARY KEY,
    Ad VARCHAR(50),
    Unvan VARCHAR(50)
);

CREATE TABLE FactMaasOdemeleri (
    OdemeID INT PRIMARY KEY,
    CalisanID INT, 
    DepartmanID INT, 
    OdemeTarihi DATE,
    NetMaas INT,
    Prim INT
);