SELECT
Ad,
Departman,
Maas,
AVG(Maas) OVER(PARTITION BY Departman) AS Departman_Ortalamasi,
Maas-AVG(Maas) OVER(PARTITION BY Departman) AS Ortalamadan_Fark FROM Calisanlar;