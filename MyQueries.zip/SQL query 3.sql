SELECT 
Ad,
Departman,
Maas,
LEAD(Maas,1) OVER(PARTITION BY Departman ORDER BY Maas DESC) AS Bir_Sonraki_Yuksek_Maas
FROM Calisanlar;